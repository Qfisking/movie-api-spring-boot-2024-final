package nxu.it.movieapi.service.pg;

/*
public class TestDb extends BaseTestCase{
    @Autowired
    MovieDao movieDao;
    @Test
    void test_movie_cast_dao() {
        List<CastEntity> castList=movieDao.findCastByMovieId(1291543);
        castList.forEach(System.out::println);
    }
}
*/

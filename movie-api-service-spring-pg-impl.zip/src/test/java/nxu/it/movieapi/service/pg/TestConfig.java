package nxu.it.movieapi.service.pg;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "nxu.it")
public class TestConfig {
}

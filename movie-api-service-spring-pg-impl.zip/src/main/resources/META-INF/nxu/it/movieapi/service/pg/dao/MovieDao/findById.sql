SELECT *
FROM movie
WHERE id=/* movieId */129543
SELECT *
FROM comment
WHERE user_id=/*userId*/1
SELECT *
FROM comment
WHERE movie_id=/*movieId*/1
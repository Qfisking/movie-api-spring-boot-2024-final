SELECT *
FROM staff
WHERE id=/* staffId */129543